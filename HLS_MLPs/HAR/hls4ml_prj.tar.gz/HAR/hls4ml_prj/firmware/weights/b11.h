//Numpy array shape [6]
//Min -0.031250000000
//Max 0.031250000000
//Number of zeros 1

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[6];
#else
bias11_t b11[6] = {0.031250, -0.031250, -0.015625, 0.015625, 0.000000, -0.031250};
#endif

#endif
