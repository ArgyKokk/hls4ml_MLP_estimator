//Numpy array shape [5]
//Min -0.195312500000
//Max 0.187500000000
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[5];
#else
bias11_t b11[5] = {-0.1953125, -0.0156250, 0.1718750, -0.0781250, 0.1875000};
#endif

#endif
