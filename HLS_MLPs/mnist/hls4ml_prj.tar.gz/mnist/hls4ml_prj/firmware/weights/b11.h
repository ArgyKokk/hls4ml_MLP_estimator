//Numpy array shape [10]
//Min -0.125000000000
//Max 0.140625000000
//Number of zeros 1

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[10];
#else
bias11_t b11[10] = {0.093750, 0.031250, -0.125000, -0.093750, 0.093750, 0.140625, 0.015625, -0.015625, 0.000000, -0.093750};
#endif

#endif
