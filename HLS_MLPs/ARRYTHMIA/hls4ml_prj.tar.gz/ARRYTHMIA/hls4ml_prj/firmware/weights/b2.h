//Numpy array shape [8]
//Min -0.054687500000
//Max 0.078125000000
//Number of zeros 1

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[8];
#else
bias2_t b2[8] = {-0.0156250, 0.0234375, -0.0156250, -0.0546875, -0.0078125, 0.0468750, 0.0781250, 0.0000000};
#endif

#endif
