//Numpy array shape [3]
//Min -0.007812500000
//Max 0.468750000000
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[3];
#else
bias2_t b2[3] = {0.3750000, -0.0078125, 0.4687500};
#endif

#endif
