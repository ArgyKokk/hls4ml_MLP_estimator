//Numpy array shape [3]
//Min -1.000000000000
//Max 0.914062500000
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[3];
#else
bias5_t b5[3] = {0.9140625, -0.3671875, -1.0000000};
#endif

#endif
