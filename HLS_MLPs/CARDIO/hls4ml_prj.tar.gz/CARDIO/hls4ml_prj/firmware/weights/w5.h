//Numpy array shape [3, 3]
//Min -1.000000000000
//Max 0.992187500000
//Number of zeros 0

#ifndef W5_H_
#define W5_H_

#ifndef __SYNTHESIS__
weight5_t w5[9];
#else
weight5_t w5[9] = {0.9921875, -0.9921875, -1.0000000, -1.0000000, 0.9921875, 0.9531250, -0.9843750, -1.0000000, 0.9921875};
#endif

#endif
