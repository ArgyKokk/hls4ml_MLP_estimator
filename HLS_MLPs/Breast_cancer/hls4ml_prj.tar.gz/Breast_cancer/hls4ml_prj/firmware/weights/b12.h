//Numpy array shape [2]
//Min -0.242187500000
//Max 0.242187500000
//Number of zeros 0

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
bias12_t b12[2];
#else
bias12_t b12[2] = {0.2421875, -0.2421875};
#endif

#endif
