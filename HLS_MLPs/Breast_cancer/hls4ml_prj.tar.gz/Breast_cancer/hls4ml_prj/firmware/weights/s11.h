//Numpy array shape [3]
//Min 2.000000000000
//Max 2.000000000000
//Number of zeros 0

#ifndef S11_H_
#define S11_H_

#ifndef __SYNTHESIS__
model_default_t s11[3];
#else
model_default_t s11[3] = {2.0000000000, 2.0000000000, 2.0000000000};
#endif

#endif
