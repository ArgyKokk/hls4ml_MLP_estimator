//Numpy array shape [3]
//Min -0.085937500000
//Max 0.406250000000
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[3];
#else
bias5_t b5[3] = {0.0000000, 0.0000000, 0.0000000};
#endif

#endif
