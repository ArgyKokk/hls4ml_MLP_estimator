//Numpy array shape [2]
//Min 2.000000000000
//Max 2.000000000000
//Number of zeros 0

#ifndef S12_H_
#define S12_H_

#ifndef __SYNTHESIS__
model_default_t s12[2];
#else
model_default_t s12[2] = {2.0000000000, 2.0000000000};
#endif

#endif
