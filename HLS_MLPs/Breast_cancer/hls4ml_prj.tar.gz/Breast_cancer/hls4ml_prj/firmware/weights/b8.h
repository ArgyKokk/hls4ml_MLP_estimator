//Numpy array shape [2]
//Min -0.242187500000
//Max 0.242187500000
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
bias8_t b8[2];
#else
bias8_t b8[2] = {0.0000000, 0.0000000};
#endif

#endif
