//Numpy array shape [3, 2]
//Min -2.000000000000
//Max 1.250000000000
//Number of zeros 2

#ifndef W8_H_
#define W8_H_

#ifndef __SYNTHESIS__
weight8_t w8[6];
#else
weight8_t w8[6] = {0.0000000, 0.0000000, -1.0000000, 0.3828125, 0.6250000, -0.9921875};
#endif

#endif
